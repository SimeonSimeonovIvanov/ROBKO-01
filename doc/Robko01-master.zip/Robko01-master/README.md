# Robko01

This is application is dedicated to control a micro robot Robko01.
Robko01 has been developed in 1985, by BAS-ISIR.
Originally robot is developed for educational purposes.
Until now, the robot controller has been changed in case of computer hardware changes.
By now 4-5 robot controllers has been developed. Only 3 of it has been integrated to this software.
This software is fully open source and free. Fill free to rebranche it and redeveloped it.

## Key Features

### Software
1. Dot NET
2. Windows Forms

### Hardware
1. Robko01
2. USB
3. Serial port