﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace KeystrokEventGenerator
{
    class KeyCombinations
    {
        /// <summary>
        /// Open applicationConfiguration manager.
        /// </summary>
        //public const int OPEN_CONFIGURATION_MANAGER = (int)(Keys.Control | Keys.Alt | Keys.C);

        /// <summary>
        /// Open applicationConfiguration manager.
        /// </summary>
        public const int ESCAPE = (int)Keys.Escape;

        /// <summary>
        /// Configuration manager key combination.
        /// </summary>
        //public const int APPLICATION_EXIT = (int)(Keys.Control | Keys.Alt | Keys.X);

        
        /// <summary>
        /// Copy
        /// </summary>
        public const int CTRL_C = (int)(Keys.Control | Keys.C);

        /// <summary>
        /// Cut
        /// </summary>
        public const int CTRL_X = (int)(Keys.Control | Keys.X);
        
        /// <summary>
        /// Paste
        /// </summary>
        public const int CTRL_V = (int)(Keys.Control | Keys.V);

        /// <summary>
        /// Save
        /// </summary>
        public const int CTRL_S = (int)(Keys.Control | Keys.S);

        /// <summary>
        /// Undo
        /// </summary>
        public const int CTRL_Z = (int)(Keys.Control | Keys.Z);

        /// <summary>
        /// Undo
        /// </summary>
        public const int CTRL_Y = (int)(Keys.Control | Keys.Y);

        /// <summary>
        /// Undo
        /// </summary>
        public const int CTRL_O = (int)(Keys.Control | Keys.O);

        
        /// <summary>
        /// Undo
        /// </summary>
        public const int DELETE = (int)(Keys.Delete);

        /// <summary>
        /// Pan
        /// </summary>
        public const int P = (int)(Keys.P);

        /// <summary>
        /// Arow up
        /// </summary>
        public const int AROW_UP = (int)Keys.Up;

    }
}
