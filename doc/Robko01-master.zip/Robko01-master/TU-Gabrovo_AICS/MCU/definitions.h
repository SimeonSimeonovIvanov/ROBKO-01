//definitions

#define INPUT		1
#define OUTPUT	0

#define TRUE		1
#define FALSE		0
#define true		1
#define false		0

#define DISABLE  0
#define ENABLE   1

///////////////////////////////////////////

#define TX	RC6
#define RX	RC7
#define TX_TRIS	TRISC6
#define RX_TRIS	TRISC7

// define sensors(buttons)
#define BUT0	RA0
#define BUT1	RA1
#define BUT2	RA2
#define BUT3	RA3
#define BUT4	RA4
#define BUT5	RA5

#define BUT0_TRIS		TRISA0
#define BUT1_TRIS		TRISA1
#define BUT2_TRIS		TRISA2
#define BUT3_TRIS		TRISA3
#define BUT4_TRIS		TRISA4
#define BUT5_TRIS		TRISA5

//DEFINE PLC INPUTC
#define PLC0	RD4
#define PLC1	RD5
#define PLC2	RD6
#define PLC3	RD7
#define PLC4	RD3
#define PLC5	RD2

#define 	PLC_SEL		PLC0	
#define 	PLC_A0			PLC1	
#define	PLC_A1			PLC2	
#define 	PLC_A2			PLC3	
#define 	PLC_DIR		PLC4	
#define 	PLC_STEP		PLC5	

#define PLC0_TRIS		TRISD4
#define PLC1_TRIS		TRISD5
#define PLC2_TRIS		TRISD6
#define PLC3_TRIS		TRISD7
#define PLC4_TRIS		TRISD3
#define PLC5_TRIS		TRISD2

//SHIFT REGISTERS CONTROL
#define SI1		RB4
#define SI2		RB2
#define SI3		RB1
#define SI4		RB3
#define SI5		RB0
#define STRB	RB5
#define CLK	RE0

#define SI1_TRIS		TRISB4
#define SI2_TRIS		TRISB2
#define SI3_TRIS		TRISB1
#define SI4_TRIS		TRISB3
#define SI5_TRIS		TRISB0
#define STRB_TRIS		TRISB5
#define CLK_TRIS		TRISE0

//Variables
 unsigned char  in_str[20];
unsigned char RX_counter;
int rs485_timeout;
unsigned char num_bytes;
unsigned char InBuf[20];
unsigned char parse_flag;
unsigned char error_flag;
unsigned char str_counter; //COUNTS NUMBER OF BYTES N RECEIVED STRING

//RS485 parser dependent variables
#define ERROR			1
#define NO_ERROR		0

//definitions of motor variables
unsigned char Data[5]; 


//steps set point
volatile unsigned int StepsNumber[6]; //one for each driver
volatile unsigned int CurrentStep[6]; //
volatile unsigned char Direction[6]; //direction of rotation
volatile unsigned int StepTime[6];// time between steps in ms
volatile unsigned int CurrentTimeout[6];//
volatile unsigned char StepState[6]; //current state for drivers
volatile unsigned char NextStepState[6]; //next state
volatile unsigned char MotorFlag[6]; //enable or disable motor

//step states
#define ST0	0
#define ST1	1
#define ST2	3
#define ST3	2

#define ENABLE_CURRENT	0x00
#define DISABLE_CURRENT 0x0f
volatile unsigned char CurrentEnable[6];

