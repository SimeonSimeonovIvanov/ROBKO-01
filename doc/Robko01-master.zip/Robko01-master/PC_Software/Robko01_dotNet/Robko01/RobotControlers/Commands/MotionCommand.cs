﻿using Robko01.RobotControlers.TUGAB;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Robko01.RobotControlers.Commands
{
    [Serializable]
    public class MotionCommand : EventArgs
    {

        #region Variables

        /// <summary>
        /// Axis index.
        /// </summary>
        public int Axis = -2;

        /// <summary>
        /// Delay
        /// </summary>
        public int Delay = 0;

        /// <summary>
        /// Steps
        /// </summary>
        public int Steps = 0;

        #endregion

        #region Constructor

        public MotionCommand()
        {

        }

        public MotionCommand(int axis, int delay, int steps)
        {
            this.Axis = axis;
            this.Delay = delay;
            this.Steps = steps;
        }

        #endregion

        #region Public

        /// <summary>
        /// Calculate motion time.
        /// </summary>
        /// <returns>Consumed motion time.</returns>
        public float WaitTime()
        {
            return Math.Abs(((float)this.Steps * ((float)Delay * 2.5f)));
        }

        /// <summary>
        /// Compile protocol command.
        /// </summary>
        /// <returns>Command</returns>
        public string ToCommand()
        {
            string direction = "";

            if(this.Steps > 0)
            {
                direction = JointDirection.CW;
            }
            else
            {
                direction = JointDirection.CCW;
            }

            return String.Format("?F{0}:{1}{2:D4}:{3:D4}", this.Axis, direction, this.Steps, this.Delay);
        }

        /// <summary>
        /// Generate string descriptoin.
        /// </summary>
        /// <returns>Text</returns>
        public override string ToString()
        {
            string direction = "";

            if (this.Steps > 0)
            {
                direction = JointDirection.CW;
            }
            else
            {
                direction = JointDirection.CCW;
            }

            return String.Format("Axis: {0}; Steps: {1}{2}; Delay: {3}", ((JointName)this.Axis).ToString(), direction, Math.Abs(this.Steps), this.Delay);
        }

        #endregion

    }
}
