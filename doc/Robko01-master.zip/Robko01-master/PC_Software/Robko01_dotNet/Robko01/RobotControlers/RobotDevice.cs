﻿using Robko01.RobotControlers.Messages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Robko01.RobotControlers
{
    class RobotDevice
    {
        #region Variables

        /// <summary>
        /// 
        /// </summary>
        private object robot = null;
        
        /// <summary>
        /// 
        /// </summary>
        private Type type = null;

        #endregion 

        #region Properties

        public bool IsConnected
        {
            get
            {
                bool isConnected = false;

                if (this.type == typeof(RobotControlers.TUGAB.Robko01))
                {
                    isConnected = ((RobotControlers.TUGAB.Robko01)this.robot).IsConnected;
                }
                else if (this.type == typeof(RobotControlers.VALNIKO.Robko01))
                {
                    isConnected = ((RobotControlers.VALNIKO.Robko01)this.robot).IsConnected;
                }
                else if (this.type == typeof(RobotControlers.SVSHADY.Robko01))
                {
                    isConnected = ((RobotControlers.SVSHADY.Robko01)this.robot).IsConnected;
                }

                return isConnected;
            }
        }

        public bool IsRuning
        {
            get
            {
                bool state = false;

                if (this.type == typeof(RobotControlers.TUGAB.Robko01))
                {
                    state = ((RobotControlers.TUGAB.Robko01)this.robot).IsRuning;
                }
                else if (this.type == typeof(RobotControlers.VALNIKO.Robko01))
                {
                    state = ((RobotControlers.VALNIKO.Robko01)this.robot).IsRuning;
                }
                else if (this.type == typeof(RobotControlers.SVSHADY.Robko01))
                {
                    state = ((RobotControlers.SVSHADY.Robko01)this.robot).IsRuning;
                }

                return state;
            }
        }

        #endregion

        #region Construcotr

        public RobotDevice(object robot)
        {
            if (robot == null)
            {
                throw new ArgumentNullException("Must pass a valid robot instance.");
            }

            this.type = robot.GetType();
            this.robot = robot;
        }

        #endregion

        #region Private Methodas

        // ...

        #endregion
        
        #region Public Methods

        /// <summary>
        /// Connect to the robot.
        /// </summary>
        public void Connect()
        {
            if (this.type == typeof(RobotControlers.TUGAB.Robko01))
            {
                ((RobotControlers.TUGAB.Robko01)this.robot).Connect();
            }
            else if (this.type == typeof(RobotControlers.VALNIKO.Robko01))
            {
                ((RobotControlers.VALNIKO.Robko01)this.robot).Connect();
            }
            else if (this.type == typeof(RobotControlers.SVSHADY.Robko01))
            {
                ((RobotControlers.SVSHADY.Robko01)this.robot).Connect();
            }
            else
            {
                throw new NotImplementedException("This method is not implemented for this model: " + this.type.Name);
            }
        }

        /// <summary>
        /// Disconnect from the robot.
        /// </summary>
        public void Disconnect()
        {
            if (this.type == typeof(RobotControlers.TUGAB.Robko01))
            {
                ((RobotControlers.TUGAB.Robko01)this.robot).Disconnect();
            }
            else if (this.type == typeof(RobotControlers.VALNIKO.Robko01))
            {
                ((RobotControlers.VALNIKO.Robko01)this.robot).Disconnect();
            }
            else if (this.type == typeof(RobotControlers.SVSHADY.Robko01))
            {
                ((RobotControlers.SVSHADY.Robko01)this.robot).Disconnect();
            }
            else
            {
                throw new NotImplementedException("This method is not implemented for this model: " + this.type.Name);
            }
        }

        public void SendRawRequest(string command)
        {
            if (this.type == typeof(RobotControlers.TUGAB.Robko01))
            {
                ((RobotControlers.TUGAB.Robko01)this.robot).SendRawRequest(command);
            }
            else if (this.type == typeof(RobotControlers.VALNIKO.Robko01))
            {
                ((RobotControlers.VALNIKO.Robko01)this.robot).SendRawRequest(command);
            }
            else if (this.type == typeof(RobotControlers.SVSHADY.Robko01))
            {
                ((RobotControlers.SVSHADY.Robko01)this.robot).SendRawRequest(command);
            }
            else
            {
                throw new NotImplementedException("This method is not implemented for this model: " + this.type.Name);
            }
        }

        /// <summary>
        /// On runing trought the commands.
        /// </summary>
        /// <param name="handler"></param>
        public void SetOnMoveingEvent(EventHandler<EventArgs> handler)
        {
            if (this.type == typeof(RobotControlers.TUGAB.Robko01))
            {
                ((RobotControlers.TUGAB.Robko01)this.robot).OnMoveing += handler;
            }
            else if (this.type == typeof(RobotControlers.VALNIKO.Robko01))
            {
                ((RobotControlers.VALNIKO.Robko01)this.robot).OnMoveing += handler;
            }
            else if (this.type == typeof(RobotControlers.SVSHADY.Robko01))
            {
                ((RobotControlers.SVSHADY.Robko01)this.robot).OnMoveing += handler;
            }
            else
            {
                throw new NotImplementedException("This method is not implemented for this model: " + this.type.Name);
            }
        }

        /// <summary>
        /// Raise when motor stops moveing.
        /// </summary>
        /// <param name="handler"></param>
        public void SetOnNotMoveingEvent(EventHandler<EventArgs> handler)
        {
            if (this.type == typeof(RobotControlers.TUGAB.Robko01))
            {
                ((RobotControlers.TUGAB.Robko01)this.robot).OnNotMoveing += handler;
            }
            else if (this.type == typeof(RobotControlers.VALNIKO.Robko01))
            {
                ((RobotControlers.VALNIKO.Robko01)this.robot).OnNotMoveing += handler;
            }
            else if (this.type == typeof(RobotControlers.SVSHADY.Robko01))
            {
                ((RobotControlers.SVSHADY.Robko01)this.robot).OnNotMoveing += handler;
            }
            else
            {
                throw new NotImplementedException("This method is not implemented for this model: " + this.type.Name);
            }
        }

        /// <summary>
        /// Recieved command message.
        /// </summary>
        /// <param name="handler"></param>
        public void SetOnMesageEvent(EventHandler<MessageString> handler)
        {
            if (this.type == typeof(RobotControlers.TUGAB.Robko01))
            {
                ((RobotControlers.TUGAB.Robko01)this.robot).OnMesage += handler;
            }
            else if (this.type == typeof(RobotControlers.VALNIKO.Robko01))
            {
                ((RobotControlers.VALNIKO.Robko01)this.robot).OnMesage += handler;
            }
            else if (this.type == typeof(RobotControlers.SVSHADY.Robko01))
            {
                ((RobotControlers.SVSHADY.Robko01)this.robot).OnMesage += handler;
            }
            else
            {
                throw new NotImplementedException("This method is not implemented for this model: " + this.type.Name);
            }
        }

        #endregion

        internal void Stop(int axis)
        {
            if (this.type == typeof(RobotControlers.TUGAB.Robko01))
            {
                ((RobotControlers.TUGAB.Robko01)this.robot).Stop(axis);
            }
            else if (this.type == typeof(RobotControlers.VALNIKO.Robko01))
            {
                ((RobotControlers.VALNIKO.Robko01)this.robot).ShutdownAll();
            }
            else if (this.type == typeof(RobotControlers.SVSHADY.Robko01))
            {
                ((RobotControlers.SVSHADY.Robko01)this.robot).Stop(axis);
            }
            else
            {
                throw new NotImplementedException("This method is not implemented for this model: " + this.type.Name);
            }
        }

        internal void Disable(int axis)
        {
            if (this.type == typeof(RobotControlers.TUGAB.Robko01))
            {
                ((RobotControlers.TUGAB.Robko01)this.robot).Disable(axis);
            }
            else if (this.type == typeof(RobotControlers.VALNIKO.Robko01))
            {
                // Do nothing to this type of controller.
                //((RobotControlers.VALNIKO.Robko01)this.robot).ShutdownAll();
            }
            else if (this.type == typeof(RobotControlers.SVSHADY.Robko01))
            {
                ((RobotControlers.SVSHADY.Robko01)this.robot).Disable(axis);
            }
            else
            {
                throw new NotImplementedException("This method is not implemented for this model: " + this.type.Name);
            }
        }

        internal void Enable(int axis)
        {
            if (this.type == typeof(RobotControlers.TUGAB.Robko01))
            {
                ((RobotControlers.TUGAB.Robko01)this.robot).Enable(axis);
            }
            else if (this.type == typeof(RobotControlers.VALNIKO.Robko01))
            {
                // Do nothing for this type of controller.
                //((RobotControlers.VALNIKO.Robko01)this.robot).ShutdownAll();
            }
            else if (this.type == typeof(RobotControlers.SVSHADY.Robko01))
            {
                ((RobotControlers.SVSHADY.Robko01)this.robot).Enable(axis);
            }
            else
            {
                throw new NotImplementedException("This method is not implemented for this model: " + this.type.Name);
            }
        }

        internal void MoveRelative(JointName jointName, int delay, int steps)
        {
            if (this.type == typeof(RobotControlers.TUGAB.Robko01))
            {
                ((RobotControlers.TUGAB.Robko01)this.robot).MoveRelative(jointName, delay, steps);
            }
            else if (this.type == typeof(RobotControlers.VALNIKO.Robko01))
            {
                ((RobotControlers.VALNIKO.Robko01)this.robot).MoveJoint((int)jointName, steps, delay, VALNIKO.StepMode.HalfStep);
            }
            else if (this.type == typeof(RobotControlers.SVSHADY.Robko01))
            {
                ((RobotControlers.SVSHADY.Robko01)this.robot).MoveRelative((int)jointName, steps, delay);
            }
            else
            {
                throw new NotImplementedException("This method is not implemented for this model: " + this.type.Name);
            }
        }

        internal void MoveRelative(Commands.MotionCommand command)
        {
            switch ((JointName)command.Axis)
            {
                case JointName.Elbow:
                    this.MoveRelativeElbow(command.Delay, command.Steps);
                    break;

                case JointName.Pitch:
                    this.MoveRelativePich(command.Delay, command.Steps);
                    break;

                case JointName.Roll:
                    this.MoveRelativeRoll(command.Delay, command.Steps);
                    break;

                default:
                    this.MoveRelative((JointName)command.Axis, command.Delay, command.Steps);
                    break;
            }
        }

        internal void MoveRelativePich(int delay, int steps)
        {
            if (this.type == typeof(RobotControlers.TUGAB.Robko01))
            {
                ((RobotControlers.TUGAB.Robko01)this.robot).MoveRelativePich(delay, steps);
            }
            else if (this.type == typeof(RobotControlers.VALNIKO.Robko01))
            {
                //((RobotControlers.VALNIKO.Robko01)this.robot).MoveJoint((int)jointName, steps, delay, VALNIKO.StepMode.HalfStep);
            }
            else if (this.type == typeof(RobotControlers.SVSHADY.Robko01))
            {
                //((RobotControlers.SVSHADY.Robko01)this.robot).MoveRelative((int)jointName, steps, delay);
            }
            else
            {
                throw new NotImplementedException("This method is not implemented for this model: " + this.type.Name);
            }
        }

        internal void EnablePichRoll(bool state)
        {
            if (this.type == typeof(RobotControlers.TUGAB.Robko01))
            {
                ((RobotControlers.TUGAB.Robko01)this.robot).EnablePichRoll(state);
            }
            else if (this.type == typeof(RobotControlers.VALNIKO.Robko01))
            {
                //((RobotControlers.VALNIKO.Robko01)this.robot).MoveJoint((int)jointName, steps, delay, VALNIKO.StepMode.HalfStep);
            }
            else if (this.type == typeof(RobotControlers.SVSHADY.Robko01))
            {
                //((RobotControlers.SVSHADY.Robko01)this.robot).MoveRelative((int)jointName, steps, delay);
            }
            else
            {
                throw new NotImplementedException("This method is not implemented for this model: " + this.type.Name);
            }
        }

        internal void MoveRelativeRoll(int delay, int steps)
        {
            if (this.type == typeof(RobotControlers.TUGAB.Robko01))
            {
                ((RobotControlers.TUGAB.Robko01)this.robot).MoveRelativeRoll(delay, steps);
            }
            else if (this.type == typeof(RobotControlers.VALNIKO.Robko01))
            {
                //((RobotControlers.VALNIKO.Robko01)this.robot).MoveJoint((int)jointName, steps, delay, VALNIKO.StepMode.HalfStep);
            }
            else if (this.type == typeof(RobotControlers.SVSHADY.Robko01))
            {
                //((RobotControlers.SVSHADY.Robko01)this.robot).MoveRelative((int)jointName, steps, delay);
            }
            else
            {
                throw new NotImplementedException("This method is not implemented for this model: " + this.type.Name);
            }
        }

        internal void EnableElbow(bool state)
        {
            if (this.type == typeof(RobotControlers.TUGAB.Robko01))
            {
                ((RobotControlers.TUGAB.Robko01)this.robot).EnableElbow(state);
            }
            else if (this.type == typeof(RobotControlers.VALNIKO.Robko01))
            {
                //((RobotControlers.VALNIKO.Robko01)this.robot).MoveJoint((int)jointName, steps, delay, VALNIKO.StepMode.HalfStep);
            }
            else if (this.type == typeof(RobotControlers.SVSHADY.Robko01))
            {
                //((RobotControlers.SVSHADY.Robko01)this.robot).MoveRelative((int)jointName, steps, delay);
            }
            else
            {
                throw new NotImplementedException("This method is not implemented for this model: " + this.type.Name);
            }
        }

        internal void MoveRelativeElbow(int delay, int steps)
        {
            if (this.type == typeof(RobotControlers.TUGAB.Robko01))
            {
                ((RobotControlers.TUGAB.Robko01)this.robot).MoveRelativeElbow(delay, steps);
            }
            else if (this.type == typeof(RobotControlers.VALNIKO.Robko01))
            {
                //((RobotControlers.VALNIKO.Robko01)this.robot).MoveJoint((int)jointName, steps, delay, VALNIKO.StepMode.HalfStep);
            }
            else if (this.type == typeof(RobotControlers.SVSHADY.Robko01))
            {
                //((RobotControlers.SVSHADY.Robko01)this.robot).MoveRelative((int)jointName, steps, delay);
            }
            else
            {
                throw new NotImplementedException("This method is not implemented for this model: " + this.type.Name);
            }
        }

    }
}
