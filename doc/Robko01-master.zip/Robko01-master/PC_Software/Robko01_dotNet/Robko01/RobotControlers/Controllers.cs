﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Robko01.RobotControlers
{
    public enum Controllers : uint
    {
        None = 0,
        TUGAB = 1,
        VALNIKO = 2,
        SVSHADY = 3
    }
}
