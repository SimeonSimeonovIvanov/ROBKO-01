﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Robko01
{
    public static class AppUtils
    {
        public static string CreateProgramName()
        {
            DateTime time = DateTime.Now;             // Use current time.
            string format = "yyMMddHHmmss";   // Use this format.
            return "Robko01_" + time.ToString(format);
        }

        public static int ValidateDelay(string value)
        {
            int delay = 0;
            bool valid = Int32.TryParse(value, out delay);

            if (!valid)
            {
                delay = 0;
            }

            if (delay < 0)
            {
                delay = 0;
            }

            return delay;
        }

        public static int ValidateSteps(string value)
        {
            int steps = 0;
            bool valid = int.TryParse(value, out steps);

            if (!valid)
            {
                steps = 0;
            }

            return steps;
        }


    }
}
