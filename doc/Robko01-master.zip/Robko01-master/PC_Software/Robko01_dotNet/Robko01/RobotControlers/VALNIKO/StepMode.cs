﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Robko01.RobotControlers.VALNIKO
{
    public enum StepMode : int
    {
        /// <summary>
        /// Full step.
        /// </summary>
        /// <remarks>
        /// Step A  B  A\ B\
        /// 0    1  1  0  0
        /// 1    0  1  1  0
        /// 2    0  0  1  1
        /// 3    1  0  0  1 
        /// </remarks>
        FullStep = 1,

        /// <summary>
        /// Half step.
        /// </summary>
        /// <remarks>
        /// Step A  B  A\ B\
        /// 0    1  1  0  0
        /// 1    0  1  0  0
        /// 2    0  1  1  0
        /// 3    0  0  1  0
        /// 4    0  0  1  1
        /// 5    0  0  0  1
        /// 6    1  0  0  1
        /// 7    1  0  0  0
    /// </remarks>
        HalfStep = 2
    }
}
