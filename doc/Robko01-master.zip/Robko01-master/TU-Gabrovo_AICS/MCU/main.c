#include <htc.h>
#include <stdio.h>
#include "definitions.h"
#include "usart.h"
#include "timer1.h"
#include "eeprom.h"

//configurations
__CONFIG(1, HS);
__CONFIG(2,  PWRTEN & WDTDIS);
__CONFIG(4, STVRDIS&LVPDIS);
__CONFIG(5, CPA);

//eeprom
__EEPROM_DATA(0,0,0,0,0,0,0,0); //0-3
__EEPROM_DATA(0,0,0,0,0,0,0,0); //4-7
__EEPROM_DATA(0,0,0,0,0,0,0,0); //8-11
__EEPROM_DATA(0,0,0,0,0,0,0,0); //12-15
__EEPROM_DATA(0,0,0,0,0,0,0,0); //16-19
__EEPROM_DATA(0,0,0,0,0,0,0,0); 
__EEPROM_DATA(0,0,0,0,0,0,0,0); 
__EEPROM_DATA(0,0,0,0,0,0,0,0); 

void InitPeriphery(void);
void Parser(void);
void WriteStepperDrivers(void);
void RefreshDrivers(void);
int GetData(unsigned char * pointer);

void main(void)
{
	volatile int i;
	
	InitPeriphery();
	InitTimer1();
	InitUSART(0);
	IPEN = 1; // interrupt priorities enabled
	TMR1IP=0;
	GIEL = 1;
	GIEH = 1; //enable interrupts
	
	//test code
	for(i=0;i<5;i++)
	{
		Data[i]=0x00;
	}
	for(i=0; i<6;i++)
	{
		StepsNumber[i] = 1000;
		CurrentStep[i] = 0;
		StepTime[i] = 400;
		CurrentTimeout[i]=0;
		CurrentEnable[i]=DISABLE_CURRENT;
		
	//	MotorFlag[i]=ENABLE;
	}

	while(1)
	{
		if (parse_flag==ENABLE)
		{
			parse_flag=DISABLE;
			Parser();	
		}
	}
}



//***************************************************************************
// Interrupt routine
//***************************************************************************
void interrupt Inter()
{

	static char data;
	static char i;
	
	GIEH=0;

	if((RCIE==1)&&(RCIF==1))
	{
		data=RCREG;
		RX_counter++;
		rs485_timeout=20;
		switch(data)
		{
			
		case 0x0A : 
					parse_flag=ENABLE;
			
					num_bytes=str_counter;
					for	(i=0;i<num_bytes;i++)
					{
						in_str[i]=InBuf[i];
					}
						in_str[i]=0; //TERMINATE WITH ZERO
						i++;
						in_str[i]=0; //TERMINATE WITH ZERO
						str_counter=0;
				break;
		
			default: if (str_counter<19)
					{
					
						(InBuf[str_counter])=RCREG;
							str_counter++;
					}
					else
					{
					error_flag=ERROR;
					str_counter=0;
					}
					
					break;
			
		}
		//test code, remove after
	
		//////////////////////////////////////
		RCIF=0; //clear flag
		RCIE=1;
		CREN=0; //clear potential errors
		asm("nop");
		CREN=1;
	}
	GIEH=1;//enable interrupts
	
}

//**************************************************************************
//		LOW Priority Interrupt
//**************************************************************************
void interrupt low_priority tc_clr(void)
{
		static char LedSelect;
	static char LedData1, LedData2;
		if ((TMR1IF==1)&&(TMR1IE==1))
	{
		GIEL = 0;
		TMR1IF=0;
			//initialize timer
		TMR1H=0xf9;
		TMR1L=0xef;  //5ms	
		
		//refresh drivers
		RefreshDrivers();
		WriteStepperDrivers();
		
	
		//rs485 timeout
		if (rs485_timeout>0)
		{
			
			rs485_timeout--;
		}
		else
			str_counter=0;
			
	
	
		
		TMR1IF=0;
		
	}
		GIEL = 1;
	
}

//Init periphery
void InitPeriphery(void)
{
 ADCON1=0x07;
 BUT0_TRIS = INPUT;
 BUT1_TRIS = INPUT;
 BUT2_TRIS = INPUT;
 BUT3_TRIS = INPUT;
 BUT4_TRIS = INPUT;
 BUT5_TRIS = INPUT;
 
 PLC0_TRIS=INPUT;
 PLC1_TRIS=INPUT;
 PLC2_TRIS=INPUT;
 PLC3_TRIS=INPUT;
 PLC4_TRIS=INPUT;
 PLC5_TRIS=INPUT;
 
SI1_TRIS=OUTPUT;		
SI2_TRIS=OUTPUT;		
SI3_TRIS=OUTPUT;		
SI4_TRIS=OUTPUT;	
SI5_TRIS=OUTPUT;		
STRB_TRIS=OUTPUT;		
CLK_TRIS=OUTPUT;	

}

//Parser of UART commands
void Parser(void)
{
	unsigned char buf_str[10];
	unsigned char  out_str[30];
	//char data_str[10];
	unsigned char command;
	volatile int i;//counter
	unsigned char temp;
	unsigned char err; //return whether there is error
	int data;
	int j;
	unsigned char send_info;
	
	
	send_info=ENABLE;
	//begin to parse
	i=0;
	
	////take comand
	if(in_str[i]=='?')
	{
		i++; //take next data
	
	command=in_str[i];
	
	switch(command)
	{
	
			case 'S':
			case 's':
					i++;
					if((in_str[i]=='A')||(in_str[i]=='a'))
					{
						for(j=0;j<=5;j++)
						{
							CurrentEnable[j]=ENABLE_CURRENT;
							if(CurrentStep[j]<StepsNumber[j])
							{
								MotorFlag[j]=ENABLE;
								SendConstStrUSART("Allmotors are on \r\n"); ///da se izvadi ot cikyla
								send_info=DISABLE;
							}
						}
					}
					else
					if((in_str[i]=='D')||(in_str[i]=='d'))
					{
						i++; //take : symbol
						
						i++;
						if(in_str[i]=='1')
						{
							MotorFlag[5]=ENABLE;
							CurrentEnable[5]=ENABLE_CURRENT;
						}
						
						i++;
						if(in_str[i]=='1')
						{
							MotorFlag[4]=ENABLE;
							CurrentEnable[4]=ENABLE_CURRENT;
						}
						
						i++;
						if(in_str[i]=='1')
						{
							MotorFlag[3]=ENABLE;
							CurrentEnable[3]=ENABLE_CURRENT;
						}
						
						i++;
						if(in_str[i]=='1')
						{
							MotorFlag[2]=ENABLE;
							CurrentEnable[2]=ENABLE_CURRENT;
						}
						
						i++;
						if(in_str[i]=='1')
						{
							MotorFlag[1]=ENABLE;
							CurrentEnable[1]=ENABLE_CURRENT;
						}
						
						i++;
						if(in_str[i]=='1')
						{
							MotorFlag[0]=ENABLE;
							CurrentEnable[0]=ENABLE_CURRENT;
						}
					}
					else	
					if((in_str[i]>'5') || (in_str[i]<'0' ))
					{
						SendConstStrUSART("Bad parameter \r\n");
						send_info=DISABLE;
					}
					else
					{
						temp = in_str[i]-0x30;
						
					//	CurrentStep[temp]=0;
						CurrentTimeout[temp]=0;
						if(CurrentStep[temp]<StepsNumber[temp])
						{
							MotorFlag[temp]=ENABLE;
							CurrentEnable[temp]=ENABLE_CURRENT;
							SendConstStrUSART("Start OK \r\n");
						}
						else
						{
							SendConstStrUSART("Operation is already done \r\n");
							
						}
					}
				
					break;
			case 'P':
			case 'p':
					i++;
					if((in_str[i]=='A')||(in_str[i]=='a'))
					{
						for(j=0;j<6;j++)
						{
							MotorFlag[j]=DISABLE;
							SendConstStrUSART(" All motors stopped  \r\n");	///da se izvadi ot cikyla
							send_info=DISABLE;
						}
						
					}
					else
					if((in_str[i]>'5') || (in_str[i]<'0' ))
					{
						SendConstStrUSART("Bad parameter \r\n");
						send_info=DISABLE;
					}
					else
					{
						temp = in_str[i]-0x30;
						MotorFlag[temp]=DISABLE;
						SendConstStrUSART(" Stop OK \r\n");
					}
				
					break;
			case 'T':
			case 't':
					i++;
					if((in_str[i]>'5') || (in_str[i]<'0' ))
					{
						SendConstStrUSART("Bad parameter \r\n");
						send_info=DISABLE;
					}
					else
					{
				
						temp=in_str[i]-0x30;
						i++;//take ':' symbol
						i++;
						data=GetData(&in_str[4]);
						StepTime[temp]=data;
						SendConstStrUSART("Time OK \r\n");
					}
				
				
					break;
			case 'A':
			case 'a':
					i++;
					if((in_str[i]>'5') || (in_str[i]<'0' ))
					{
						SendConstStrUSART("Bad parameter \r\n");
						send_info=DISABLE;
					}
					else
					{
					
						temp=in_str[i]-0x30;
						i++;//take ':' symbol
						i++;
						data=GetData(&in_str[4]);
						StepsNumber[temp]=data;
						
						CurrentStep[temp]=0;
						SendConstStrUSART("Steps OK \r\n");
					}
				
				
				
					break;
			case 'D':
			case 'd':
					i++;
					if((in_str[i]>'5') || (in_str[i]<'0' ))
					{
						SendConstStrUSART("Bad parameter \r\n");
						send_info=DISABLE;
					}
					else
					{
						temp = in_str[i]-0x30;
						i++; //take ':' symbol
						i++;
						if(in_str[i]=='+')
						{
							Direction[temp]=1;
						}
						else
						{
							Direction[temp]=0;
						}
					}
				
					break;
			case 'F':
			case 'f':
					i++;
					if((in_str[i]>'5') || (in_str[i]<'0' ))
					{
						SendConstStrUSART("Bad parameter \r\n");
						send_info=DISABLE;
					}
					else
					{
					
						temp=in_str[i]-0x30;
						i++;//take ':' symbol
						i++;//take +/-
						if(in_str[i]=='+')
						{
							Direction[temp]=1;
						}
						else
						{
							Direction[temp]=0;
						}
						i++;
						data=GetData(&in_str[i]);
						StepsNumber[temp]=data;
						i=i+4;//take ':'
						i++;
						data=GetData(&in_str[i]);
						StepTime[temp]=data;	
																
						CurrentStep[temp]=0;
						CurrentTimeout[temp]=0;
						MotorFlag[temp]=ENABLE;
						SendConstStrUSART("Operation OK \r\n");
					}
					break;
			case 'R':
			case 'r':
					i++;
					if((in_str[i]!='V') && (in_str[i]!='v' ))
					{
						SendConstStrUSART("Bad parameter \r\n");
					
					}
					else
					{
						SendConstStrUSART("Stepper motor board Rev1.1\r\n");
						
					}
					send_info=DISABLE;
					break;
			case 'N':
			case 'n':
					i++;
					if((in_str[i]=='A')||(in_str[i]=='a'))
					{
						for(j=0;j<6;j++)
						{
							CurrentEnable[j]=DISABLE_CURRENT;
							MotorFlag[j]=DISABLE;
							SendConstStrUSART(" All motors disabled  \r\n");	
							send_info=DISABLE;
						}
						
					}
					else
					if((in_str[i]>'5') || (in_str[i]<'0' ))
					{
						SendConstStrUSART("Bad parameter \r\n");
						send_info=DISABLE;
					}
					else
					{
						temp = in_str[i]-0x30;
						CurrentEnable[temp]=DISABLE_CURRENT;
						MotorFlag[temp]=DISABLE;
						sprintf(out_str, "Disable motor %d \r\n",temp);
						SendStrUSART(out_str);	
					}
					break;
			case 'E':
			case 'e':
					i++;
					if((in_str[i]=='A')||(in_str[i]=='a'))
					{
						for(j=0;j<6;j++)
						{
							CurrentEnable[j]=ENABLE_CURRENT;
						//	MotorFlag[j]=DISABLE;
							SendConstStrUSART(" All motors enabled  \r\n");
							send_info=DISABLE;	
						}
						
					}
					else
					if((in_str[i]>'5') || (in_str[i]<'0' ))
					{
						SendConstStrUSART("Bad parameter \r\n");
						send_info=DISABLE;
					}
					else
					{
						temp = in_str[i]-0x30;
						CurrentEnable[temp]=ENABLE_CURRENT;
					//	MotorFlag[temp]=DISABLE;
						sprintf(out_str, "Enable motor %d \r\n",temp);
						SendStrUSART(out_str);	
					}
					break;
		default:
		
				break;
		
	}
	}	
	else
	{	
		SendConstStrUSART("Unknown string \r\n");
		send_info=DISABLE;
	}
	//test code
	if(send_info==ENABLE)
	{
		sprintf(out_str, "Drive %d \r\n",temp);
		 SendStrUSART(out_str);
		 sprintf(out_str, "MotorFlag %d \r\n",MotorFlag[temp]);
		 SendStrUSART(out_str);
		 sprintf(out_str, "Direction %d \r\n", Direction[temp]);
		 SendStrUSART(out_str);	
		 sprintf(out_str, "StepTime %d \r\n", StepTime[temp]);
		 SendStrUSART(out_str);	
		 sprintf(out_str, "StepsNumber %d \r\n", StepsNumber[temp]);
		 SendStrUSART(out_str);	
		 sprintf(out_str, "CurrentStep %d \r\n",CurrentStep[temp]);
		 SendStrUSART(out_str);	
		 sprintf(out_str, "CurrentTimeout %d \r\n \r\n", CurrentTimeout[temp]);
		 SendStrUSART(out_str);
		 if (CurrentEnable[temp]==ENABLE_CURRENT)
		 {
		 sprintf(out_str, "CURRENT ENABLE");
		 }
		 else
		 {
			 sprintf(out_str, "CURRENT DISABLE");
		} 
		 SendStrUSART(out_str);
	}		
}


//***************************************************************************
// Write to stepper drivers
//***************************************************************************
void WriteStepperDrivers(void)
{                                 
               
                 char mask; 
                char  LedControl;
            
	               
               mask=0x80;
               
                 STRB= 0; //disable output buffers
                   CLK=0; //clock line
                          //data2 first 
                       while(mask>0)
                         {    
	                    //write data   
                           if (Data[0] & (mask))
                                      SI1=1;
                          else
                                      SI1=0;    
                                           
                            if (Data[1] & (mask))
                                      SI2=1;
                           else
                                        SI2=0;       
                                                                    
                           if (Data[2] & (mask))
                                    SI3=1;
                           else
                                    SI3=0;   
                                    
                            if (Data[3] & (mask))
                                    SI4=1;
                           else
                                    SI4=0;   
                                    
                           if (Data[4] & (mask))
                                    SI5=1;
                           else
                                    SI5=0;   
                                      
                            
                                        
                            CLK = 1;  
                          asm("nop");
                           asm("nop");
                          CLK=0;    
                          asm("nop");
                          asm("nop");
                          mask=(mask>>1);
                          }      
                          CLK=0;                                
                         STRB=1; //enable strobe signal

}                    


//***************************************************************************************
//	REFRESH DRIVERS
//***************************************************************************************
#define IDLE 0
#define 	PRESSED 1
#define LOCKED  2
void RefreshDrivers(void)
{
	volatile unsigned char i;
	static char plc_address;
	static plc_step;
	char j;
	
	if(PLC_SEL==1)
	{
		//get address of motor
	plc_address=0;
	plc_address=plc_address|((PLC_A0)<<0);
	plc_address=plc_address|((PLC_A1)<<1);
	plc_address=plc_address|((PLC_A2)<<2);
	i=plc_address;
	//sense new pulse
	if(PLC_STEP==0)
	{
		plc_step=IDLE;
	}
	else
	{
		if(plc_step==IDLE)
		{
			plc_step=PRESSED;	
		}
		else
		{
			plc_step=LOCKED;
		}
	}
	
	//make step
	if(( plc_step==PRESSED)&&(plc_address<6))
	{
		for (j=0;j<6;j++)
		{
			if(j!=i)
			{
				CurrentEnable[j]=DISABLE_CURRENT;
			}
			else
			{
				CurrentEnable[i]=ENABLE;
			}		
		}
		
			
		if(PLC_DIR==0)
				{
					switch(StepState[i])
					{
						case ST0:
							NextStepState[i]=ST1;
							break;
						case ST1:
							NextStepState[i]=ST2;
							break;
						case ST2:
							NextStepState[i]=ST3;
							break;
						case ST3:
							NextStepState[i]=ST0;
							break;
						default: 
							NextStepState[i]=ST0;
							break;
					}
				}
				else
				{
					switch(StepState[i])
					{
						case ST0:
							NextStepState[i]=ST3;
							break;
						case ST1:
							NextStepState[i]=ST0;
							break;
						case ST2:
							NextStepState[i]=ST1;
							break;
						case ST3:
							NextStepState[i]=ST2;
							break;
						default: 
							NextStepState[i]=ST0;
							break;
					}
				}
				StepState[i]=NextStepState[i];
	}
	if(plc_address>=6)
	{
		for(j=0;j<6;j++)
		{
			CurrentEnable[j]=DISABLE;	
		}	
	}
			//write steps to data registers
	Data[3]=0;
	Data[4]=0;
	Data[3]=Data[3] | (StepState[0]<<0);
	Data[3]=Data[3] | (StepState[1]<<2);
	Data[3]=Data[3] | (StepState[2]<<4);
	Data[3]=Data[3] | (StepState[3]<<6);
	Data[4]=Data[4] | (StepState[4]<<0);
	Data[4]=Data[4] | (StepState[5]<<2);
	
	// write data for current control
	Data[0]=0;
	Data[1]=0;
	Data[2]=0;
	Data[0]=Data[0]|(CurrentEnable[0]<<0);
	Data[0]=Data[0]|(CurrentEnable[1]<<4);
	Data[1]=Data[1]|(CurrentEnable[2]<<0);
	Data[1]=Data[1]|(CurrentEnable[3]<<4);
	Data[2]=Data[2]|(CurrentEnable[4]<<0);
	Data[2]=Data[2]|(CurrentEnable[5]<<4);	
	}
	else
	{
	for(i=0; i<6; i++)
	{
		CurrentTimeout[i]++;
		if(CurrentTimeout[i] >= StepTime[i]) //make next step
		{
			CurrentTimeout[i]=0; //reset timeout
			if(MotorFlag[i]==ENABLE)
			{
				if(Direction[i]==0)
				{
					switch(StepState[i])
					{
						case ST0:
							NextStepState[i]=ST1;
							break;
						case ST1:
							NextStepState[i]=ST2;
							break;
						case ST2:
							NextStepState[i]=ST3;
							break;
						case ST3:
							NextStepState[i]=ST0;
							break;
						default: 
							NextStepState[i]=ST0;
							break;
					}
				}
				else
				{
					switch(StepState[i])
					{
						case ST0:
							NextStepState[i]=ST3;
							break;
						case ST1:
							NextStepState[i]=ST0;
							break;
						case ST2:
							NextStepState[i]=ST1;
							break;
						case ST3:
							NextStepState[i]=ST2;
							break;
						default: 
							NextStepState[i]=ST0;
							break;
					}
				}
				StepState[i]=NextStepState[i];
				CurrentStep[i]++;
				if(CurrentStep[i]>=StepsNumber[i])
				{
					MotorFlag[i]=DISABLE;
				}
			}	
		}
	}
	
	//write steps to data registers
	Data[3]=0;
	Data[4]=0;
	Data[3]=Data[3] | (StepState[0]<<0);
	Data[3]=Data[3] | (StepState[1]<<2);
	Data[3]=Data[3] | (StepState[2]<<4);
	Data[3]=Data[3] | (StepState[3]<<6);
	Data[4]=Data[4] | (StepState[4]<<0);
	Data[4]=Data[4] | (StepState[5]<<2);
	
	// write data for current control
	Data[0]=0;
	Data[1]=0;
	Data[2]=0;
	Data[0]=Data[0]|(CurrentEnable[0]<<0);
	Data[0]=Data[0]|(CurrentEnable[1]<<4);
	Data[1]=Data[1]|(CurrentEnable[2]<<0);
	Data[1]=Data[1]|(CurrentEnable[3]<<4);
	Data[2]=Data[2]|(CurrentEnable[4]<<0);
	Data[2]=Data[2]|(CurrentEnable[5]<<4);
	
	}//end of if 
	
}

//*****************************************************
// take data from string
//*****************************************************
int GetData(unsigned char * pointer)
{
	int data=0;
	data =((int)(*pointer)&0x000F)*1000;
	data=data + ((int)(*(pointer+1)) &0x000f)*100;
	data=data + ((int)(*(pointer+2))&0x000f)*10;
	data=data + ((int)(*(pointer+3))&0x000f);
	return data;
}


