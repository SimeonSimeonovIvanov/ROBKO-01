//eeprom write
#include <pic18.h>
#include "eeprom.h"



int Read_word(char adr)
{
static int temp_reg;
unsigned char data;
/*GIE=0;
CLRWDT();	// Kick the dog
temp_reg = EEPROM_READ(adr);
GIE=0;
temp_reg = temp_reg<<8;
data=EEPROM_READ(adr+1);	
temp_reg = temp_reg+data;
//GIE=1;
PEIE=1;
*/
//EEADRH=0; //USE ONLY 256 CELLS
EEADR=adr;
EECON1=0;
RD=1;
while(RD==1);
temp_reg=EEDATA;
temp_reg =temp_reg<<8;
EEADR=adr+1;
RD=1;;
while(RD==1);
data=EEDATA;
temp_reg=temp_reg+data;
return temp_reg;
}

void Write_word(int data_word,char adr)
{
char data;
GIE=0;
EECON1 = 0x04;
data = (char)(data_word>>8);
CLRWDT();	// Kick the dog
EEPROM_WRITE(adr, data);
GIE=0;
data = (char)(data_word);
CLRWDT();	// Kick the dog
EEPROM_WRITE(adr+1, data);
EECON1 = 0x00;
GIE=1;
}

//read double word data
long Read_double(char adr)
{
static long temp_reg;
unsigned char data;
/*GIE=0;
CLRWDT();	// Kick the dog
temp_reg = EEPROM_READ(adr);
GIE=0;
temp_reg = temp_reg<<8;
data=EEPROM_READ(adr+1);
GIE=0;
temp_reg = temp_reg+data;
data=EEPROM_READ(adr+2);	
GIE=0;
temp_reg =temp_reg<< 8;
temp_reg = temp_reg+data;
temp_reg = temp_reg<<8;
data=EEPROM_READ(adr+3);
GIE=0;
temp_reg = temp_reg+data;
//GIE=1;
PEIE=1;
*/
//EEADRH=0; //USE ONLY 256 CELLS
EEADR=adr;
EECON1=0X01;
while(RD==1);
temp_reg=EEDATA;
temp_reg =temp_reg<<8;
EEADR=adr+1;
EECON1=0X01;
while(RD==1);
data=EEDATA;
temp_reg=temp_reg+data;
temp_reg =temp_reg<<8;
EEADR=adr+2;
EECON1=0X01;
while(RD==1);
data=EEDATA;
temp_reg=temp_reg+data;
temp_reg =temp_reg<<8;
EEADR=adr+3;
EECON1=0X01;
while(RD==1);
data=EEDATA;
temp_reg=temp_reg+data;
return temp_reg;
}

//write double word data
void Write_double(long data_word,char adr)
{
 char data;
GIE=0;
EECON1 = 0x04;
data = (char)(data_word>>24);
CLRWDT();	// Kick the dog
EEPROM_WRITE(adr, data);
GIE=0;
data = (char)(data_word>>16);
CLRWDT();	// Kick the dog
EEPROM_WRITE(adr+1, data);
GIE=0;
data = (char)(data_word>>8);
CLRWDT();	// Kick the dog
EEPROM_WRITE(adr+2, data);
GIE=0;
data = (char)(data_word);
CLRWDT();	// Kick the dog
EEPROM_WRITE(adr+3, data);
GIE=0;
EECON1 = 0x00;
GIE=1;	
}
