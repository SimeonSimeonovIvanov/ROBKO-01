﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Robko01.RemoteControl
{
    public class DriverStateEventArg : EventArgs
    {
        public ushort Base { get; set; }

        public ushort Shoulder { get; set; }

        public ushort Elbow { get; set; }

        public ushort Pitch { get; set; }

        public ushort Roll { get; set; }

        public ushort Gripper { get; set; }

        public override string ToString()
        {
            return String.Format("{0} {1} {2} {3} {4} {5}",
                this.Base,
                this.Shoulder,
                this.Elbow,
                this.Pitch,
                this.Roll,
                this.Gripper);
        }
    }
}
