﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Robko01.RemoteControl
{
    [Serializable]
    public class MotionCommandEventArg : EventArgs
    {
        public MotionCommandEventArg()
        {

        }

        public ushort BaseSteps { get; set; }

        public ushort ShoulderSteps { get; set; }

        public ushort ElbowSteps { get; set; }

        public ushort PichSteps { get; set; }

        public ushort RollSteps { get; set; }

        public ushort GripperSteps { get; set; }

        public ushort BaseDelay { get; set; }

        public ushort ShoulderDelay { get; set; }

        public ushort ElbowDelay { get; set; }

        public ushort PichDelay { get; set; }

        public ushort RollDelay { get; set; }

        public ushort GripperDelay { get; set; }

        public override string ToString()
        {
            return String.Format("{0} {1} {2} {3} {4} {5} {6} {7} {8} {9} {10} {11}", 
                this.BaseSteps,
                this.ShoulderSteps,
                this.ElbowSteps,
                this.PichSteps,
                this.RollSteps,
                this.GripperSteps,
                this.BaseDelay,
                this.ShoulderDelay,
                this.ElbowDelay,
                this.PichDelay,
                this.RollDelay,
                this.GripperDelay);
        }
    }
}
