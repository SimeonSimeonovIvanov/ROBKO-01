﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Robko01.RobotControlers.VALNIKO
{
    /// <summary>
    /// Register description
    /// </summary>
    enum FunctionRegisters : byte
    {
        /// <summary>
        /// Shut down all the joints.
        /// </summary>
        ShutdownAll = 0,

        /// <summary>
        /// Run joitn until its stops.
        /// </summary>
        RunJoint = 1,
        
        /// <summary>
        /// Read inputs.
        /// </summary>
        ReadInpust = 2,

        /// <summary>
        /// Write to outputs.
        /// </summary>
        WriteOutputs = 4,

        /// <summary>
        /// Read outputs
        /// </summary>
        ReadOutpusts = 5,
        
        /// <summary>
        /// Move joints to coordinate.
        /// </summary>
        MoveJoint = 6,

        /// <summary>
        /// Reset all joints.
        /// </summary>
        HomeJoints = 7,

        /// <summary>
        /// Read joint state.
        /// </summary>
        ReadJoint = 8,

        /// <summary>
        /// Controls all the joints.
        /// </summary>
        MultipleJoint = 9,

        /// <summary>
        /// Load set point for one single joint.
        /// </summary>
        LoadJointSetpoint = 10,

        /// <summary>
        /// Run the joints to the set point.
        /// </summary>
        RunToSetpoint = 11
    }
}
