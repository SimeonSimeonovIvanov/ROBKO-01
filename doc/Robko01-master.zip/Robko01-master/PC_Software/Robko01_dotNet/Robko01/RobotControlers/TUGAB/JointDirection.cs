﻿namespace Robko01.RobotControlers.TUGAB
{
    /// <summary>
    /// Hold the joint directions.
    /// </summary>
    public class JointDirection
    {
        /// <summary>
        /// Contra clock ways.
        /// </summary>
        public const string CCW = "-";

        /// <summary>
        /// Clock ways.
        /// </summary>
        public const string CW = "+";
    }
}
