﻿using System.Xml.Serialization;
using System.IO;

namespace Robko01.RobotControlers.Commands
{
    /// <summary>
    /// Serialize command lists and store it to the files.
    /// </summary>
    static class CommandsStore
    {

        /// <summary>
        /// Save commmands to XML.
        /// </summary>
        /// <remarks>
        /// @"c:\temp\SerializationOverview.xml"
        /// </remarks>
        /// <param name="commands">Commands</param>
        /// <param name="path">File</param>
        public static void Save(MotionCommands commands, string path)
        {
            XmlSerializer writer = new XmlSerializer(typeof(MotionCommands));
            using (StreamWriter file = new System.IO.StreamWriter(path))
            {
                writer.Serialize(file, commands);
            }
        }

        /// <summary>
        /// Read commands from XML.
        /// </summary>
        /// <remarks>@"c:\temp\SerializationOverview.xml"</remarks>
        /// <param name="path">File</param>
        /// <returns>Commands</returns>
        public static MotionCommands Load(string path)
        {
            MotionCommands commands = new MotionCommands();

            XmlSerializer reader = new XmlSerializer(typeof(MotionCommands));
            using (StreamReader file = new StreamReader(path))
            {
                commands = (MotionCommands)reader.Deserialize(file);
            }
            
            return commands;
        }

    }
}
