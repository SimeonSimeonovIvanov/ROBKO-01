﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace Robko01.RobotControlers.SVSHADY
{
    class Robko01 : Communicator
    {
        public Robko01(string portName)
            : base(portName)
        {

        }

        private void DriveMotor(byte motor, int steps)
        {
            byte[] buf = { 0xAA, 0x07, (byte)0x03, motor, (byte)((0xFF00 & steps) >> 8), (byte)(0xFF & steps), 0x55 };
            string str = System.Text.Encoding.Default.GetString(buf);
            this.SendRequest(str);

            if (motor == 3)
            {
                Thread.CurrentThread.Join(20);
                buf[3] = 0x06;
                buf[4] = (byte)((0xFF00 & -steps) >> 8);
                buf[5] = (byte)(0xFF & -steps);
                str = System.Text.Encoding.Default.GetString(buf);
                this.SendRequest(str);
            }
        }

        public bool IsRuning { get; set; }

        public EventHandler<EventArgs> OnMoveing { get; set; }

        public EventHandler<EventArgs> OnNotMoveing { get; set; }

        internal void Stop(int p)
        {
            throw new NotImplementedException();
        }

        internal void Disable(int axis)
        {
            throw new NotImplementedException();
        }

        internal void Enable(int axis)
        {
            throw new NotImplementedException();
        }

        internal void MoveRelative(int p, int steps, int delay)
        {
            throw new NotImplementedException();
        }
    }
}
