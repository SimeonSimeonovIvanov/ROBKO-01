﻿
namespace Robko01.RobotControlers.TUGAB
{
    class ResponseKeys
    {
        public static string EnableMotor = "Enable motor";
        public static string DisableMotor = "Disable motor";

        public static string Drive = "Drive";
        public static string Direction = "Direction";
        public static string MotorFlag = "Motor Flag";
        public static string StepTime = "StepTime";
        public static string StepsNumber = "Steps Number";
        public static string CurrentStep = "Current Step";
        public static string CurrentTimeout = "Current Timeout";
        public static string CurrentEnable = "Current Enable";
        public static string CurrentDisable = "Current Disable";
    }
}
