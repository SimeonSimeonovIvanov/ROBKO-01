#define TX RC6
#define RX RC7
#define TX_TRIS TRISC6
#define RX_TRIS TRISC7

void SendConstUsart(const char Byte);

void InitUSART(int baud_rate)
{
//configure the lines of usart
	TRISC6 =0;
	TRISC7=1;
	SYNC=0; //asynchronous mode
	SPEN = 1;
	//generator configuration, 20MHz Fosc

	
	switch(baud_rate)
	{
		case 0:	BRGH =1; //high speed, 
			SPBRG=129;//9.6 KBaud
				break;
		case 1:	BRGH =0; //high speed, 
			SPBRG=64; //2.4KBaud
				break;
		case 2:	BRGH =0; //high speed, 
			SPBRG=129;//1.2 KBaud
				break;	
		default:	BRGH =1; //high speed, 9.6k
			SPBRG=64;
				break;
	}
	
	
	// enable receive and transmit
	CREN = 1;
	TXEN = 1;
	//enable serial port
	RCIE=1;
PEIE=1;	
//GIE = 1; 	// enable interrupt
return;
}



///////////////////////////
// send byte to PC
void SendUsart(char Byte)
{
TXREG = Byte;  
return;
}


///////////////////////////////
//// send string to PC
/*
void SendStrUSART(char* Pointer, char Number)
{
	char TempNum =0;
while(TempNum<Number)  // while is not reached end of string
{
while(TXIF == 0);   //wait while the previous byte be send
SendUsart(*Pointer); // send new byte to PC
Pointer++;	     // increment pointer
};
while(TXIF == 0); // wait to complete transimition

return;
}
*/
///////////////////////////////
//// send string to PC
void SendStrUSART(char* Pointer)
{
	int i;
//GIE=0;
while(*Pointer!= 0)  // while is not reached end of string
{
   //wait while the previous byte be send
SendUsart(*Pointer); // send new byte to PC
while(TXIF == 0);
Pointer++;	     // increment pointer
};

SendUsart(0x0a);   // send \n character to PC - da se mahne ===============================
while(TXIF == 0); // wait to complete transimition
SendUsart(0x0a);   // send \n character to PC - da se mahne ===============================
//while(TXIF == 0); // wait to complete transimition
for(i=0;i<100;i++);//delay
while(TRMT==0); //full shift register
//GIE=1;
return;
}

//const
///////////////////////////
// send byte to PC
void SendConstUsart(const char Byte)
{
TXREG =Byte;  
return;
}
 //
 //// send string to PC
void SendConstStrUSART(const char* Pointer)
{
	int i;
//	GIE=0;
while(*Pointer != 0)  // while is not reached end of string
{
   //wait while the previous byte be send
SendConstUsart(*Pointer); // send new byte to PC
while(TXIF == 0);
Pointer++;	     // increment pointer
};

SendUsart(0x0a);   // send \n character to PC
while(TXIF == 0); // wait to complete transimition
//SendUsart(0x0a);   // send \n character to PC
//while(TXIF == 0); // wait to complete transimition
for(i=0;i<100;i++);//delay
while(TRMT==0); //full shift register
//GIE=1;
return;
}


void SetBaudRate(int baud_rate)
{
		switch(baud_rate)
	{
		case 0:	BRGH =1; //high speed, 
			SPBRG=129;//9.6 KBaud
				break;
		case 1:	BRGH =1; //high speed, 
			SPBRG=64; //19.2/KBaud
				break;
		case 2:	BRGH =0; //high speed, 
			SPBRG=129;//2.4 KBaud
				break;	
		default:	BRGH =1; //high speed, 
			SPBRG=129;
				break;
	}
}
