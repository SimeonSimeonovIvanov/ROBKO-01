﻿using System;

namespace Robko01.RobotControlers.VALNIKO
{
    /// <summary>
    /// Robko01 controller.
    /// </summary>
    public class Robko01 : Communicator, IDisposable
    {

        #region Constants

        private const string TERMIN = "\r\n";

        private const int DEFAULT_ROBOT_ADDRESS = 1;

        private const string OK_CMD = "ОК\r\n";

        #endregion

        #region Variables

        /// <summary>
        /// Delimiting characters.
        /// </summary>
        private char[] delimiterChars = { '\n' };

        /// <summary>
        /// 
        /// </summary>
        private int[] steps = new int[6];

        /// <summary>
        /// Robot controller address.
        /// </summary>
        private int controllerAddress;

        #endregion

        #region Properties

        /// <summary>
        /// True when robogt is folowing the commands.
        /// Else false.
        /// </summary>
        public bool IsRuning
        {
            private set;
            get;
        }

        #endregion

        #region Events

        /// <summary>
        /// Raise when motor is runing.
        /// </summary>
        public event EventHandler<EventArgs> OnMoveing;

        /// <summary>
        /// Raise when motor stops moveing.
        /// </summary>
        public event EventHandler<EventArgs> OnNotMoveing;

        #endregion

        #region Constructor / Destructor

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="port">Comunication port.</param>
        public Robko01(string portName, int address = DEFAULT_ROBOT_ADDRESS) : base(portName)
        {
            // Save the controler address.
            this.controllerAddress = address;
        }

        /// <summary>
        /// Destructor
        /// </summary>
        ~Robko01()
        {
            this.Dispose(false);
        }

        /// <summary>
        /// Dispose
        /// </summary>
        public void Dispose()
        {
            this.Dispose(false);
        }

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                // Add resources for disposing.
            }

            this.Disconnect();
        }

        #endregion

        #region Public Methods

        #region Manual
        
        /// <summary>
        /// Shutdown all the motors.
        /// </summary>
        public void ShutdownAll()
        {
            string message = String.Format(":{0:D2}{1:D2}{2:D1}{3:D1}{4:D4}{5:D4}", this.controllerAddress, (byte)FunctionRegisters.ShutdownAll, 0, 0, 0, 0);
            this.SendRequest(message);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="joint">Index of the joint.</param>
        /// <param name="direction">Direction of the motor.</param>
        /// <param name="stepMode">Stepper motor direction.</param>
        /// <param name="delay">Delay between the steps.</param>
        public void RunJoint(int joint, JointDirection direction, StepMode stepMode, int delay = 10)
        {
            if (joint <= 5 && joint >= 0)
            {
                string message = String.Format(":{0:D2}{1:D2}{2:D1}{3:D1}{4:D4}{5:D4}", this.controllerAddress, (byte)FunctionRegisters.RunJoint, joint, (int)direction, stepMode, delay);
                this.SendRequest(message);
            }
        }

        /// <summary>
        /// Read inputs on port A.
        /// </summary>
        public void ReadInputs()
        {
            string message = String.Format(":{0:D2}{1:D2}{2:D1}{3:D1}{4:D4}{5:D4}", this.controllerAddress, (byte)FunctionRegisters.ReadInpust, 0, 0, 0, 0);
            this.SendRequest(message);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="value"></param>
        public void WriteOutputs(byte value)
        {
            int b0 = ((value & 0x01) != 0) ? 1 : 0;
            int b1 = ((value & 0x02) != 0) ? 1 : 0;
            int b2 = ((value & 0x04) != 0) ? 1 : 0;
            int b3 = ((value & 0x08) != 0) ? 1 : 0;
            int b4 = ((value & 0x10) != 0) ? 1 : 0;
            int b5 = ((value & 0x20) != 0) ? 1 : 0;
            int b6 = ((value & 0x40) != 0) ? 1 : 0;
            int b7 = ((value & 0x80) != 0) ? 1 : 0;

            string message = String.Format(":{0:D2}{1:D2}00{2:D1}{3:D1}{4:D1}{5:D1}{6:D1}{7:D1}{8:D1}{9:D1}", this.controllerAddress, (byte)FunctionRegisters.WriteOutputs, b0, b1, b2, b3, b4, b5, b6, b7);

            this.SendRequest(message);
        }

        /// <summary>
        /// Read the output state of port A.
        /// </summary>
        public void ReadOutputs()
        {
            string message = String.Format(":{0:D2}{1:D2}{2:D1}{3:D1}{4:D4}{5:D4}", this.controllerAddress, (byte)FunctionRegisters.ReadOutpusts, 0, 0, 0, 0);
            this.SendRequest(message);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="joint">Index of the joint.</param>
        /// <param name="steps">Steps to do.</param>
        /// <param name="delay">Delay between the steps.</param>
        public void MoveJoint(int joint, int steps, int delay, StepMode stepMode)
        {
            if (joint <= 5 && joint >= 0)
            {
                JointDirection direction = JointDirection.CW;
                if (steps > 0)
                {
                    direction = JointDirection.CW;
                }
                else
                {
                    direction = JointDirection.CCW;
                }

                steps = Math.Abs(steps);

                string message = String.Format(":{0:D2}{1:D2}{2:D1}{3:D1}{4:D4}{5:D1}{6:D3}", this.controllerAddress, (byte)FunctionRegisters.MoveJoint, joint, (int)direction, steps, (int)stepMode, delay);

                this.SendRequest(message);
            }
        }

        /// <summary>
        /// Home all the joints.
        /// </summary>
        public void HomeJoints(int configurationIndex = 0)
        {
            string message = String.Format(":{0:D2}{1:D2}{2:D1}{3:D1}{4:D4}{5:D4}{6:D4}", this.controllerAddress, (byte)FunctionRegisters.HomeJoints, 0, 0, 0, 0, configurationIndex);
            this.SendRequest(message);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="joint">Index of the joint.</param>
        public void ReadJoint(int joint, int sign = 0)
        {
            string message = String.Format(":{0:D2}{1:D2}{2:D1}{3:D1}{4:D4}{5:D4}", this.controllerAddress, (byte)FunctionRegisters.ReadJoint, joint, 0, 0, 0);
            this.SendRequest(message);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="stepMode">Stepper step mode.</param>
        /// <param name="action">Joints state.</param>
        /// <param name="delay">Delay between the steps.</param>
        public void MultipleJoint(StepMode stepMode, int action, int delay)
        {
            string message = String.Format(":{0:D2}{1:D2}{2:D1}{3:D1}{4:D4}{5:D4}", this.controllerAddress, (byte)FunctionRegisters.MultipleJoint, stepMode, 0, action, delay);
            this.SendRequest(message);
        }

        /// <summary>
        /// Load joint setpoint.
        /// </summary>
        /// <param name="joint">Index of the joint.</param>
        /// <param name="steps">Steps to do.</param>
        public void LoadJointSetpoint(int joint, int steps)
        {
            if (joint <= 5 && joint >= 0)
            {
                JointDirection direction = JointDirection.CW;
                if (steps > 0)
                {
                    direction = JointDirection.CW;
                }
                else
                {
                    direction = JointDirection.CCW;
                }

                steps = Math.Abs(steps);

                string message = String.Format(":{0:D2}{1:D2}{2:D1}{3:D1}{4:D4}{5:D4}", this.controllerAddress, (byte)FunctionRegisters.LoadJointSetpoint, joint, direction, steps, 0);

                this.SendRequest(message);
            }
        }

        /// <summary>
        /// Run to the setpoint.
        /// </summary>
        public void RunToSetpoint()
        {
            string message = String.Format(":{0:D2}{1:D2}{2:D1}{3:D1}{4:D4}{5:D4}", this.controllerAddress, (byte)FunctionRegisters.RunToSetpoint, 0, 0, 0, 0);
            this.SendRequest(message);
        }

        /// <summary>
        /// Converts bit signals to a integer that wil be send to the controller.
        /// </summary>
        /// <param name="states"></param>
        /// <returns></returns>
        public static int JointAction(bool[] states)
        {
            int result = 0;

            for (int index = 0; index < states.Length; index++)
            {
                int weight = (states[index]) ? (int)Math.Pow(2, states.Length - index - 1) : 0;
                result += weight;
            }

            return result;
        }

        #endregion

        #endregion

    }
}
