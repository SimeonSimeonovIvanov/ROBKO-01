#!/usr/bin/python
# -*- coding: utf-8 -*-

import os, time
from Robko01 import Robko01

# Robot port name.
port_name = None

# Program of the robot
def demo_program(robot):
	# Global speed.
	delay = 10 # unit: [ms]
	time_offset = 1 # unit: [s]
	
	# Get revision of the board.
	robot.get_revision()

	# Enable joints.
	robot.enable()
	
	wait = Robko01.calc_delay(delay, 450, time_offset)
	robot.move_relative(0, delay, 450)
	time.sleep(wait)
	
	wait = Robko01.calc_delay(delay, 450, time_offset)
	robot.move_relative(1, delay, 450)
	time.sleep(wait)

	wait = Robko01.calc_delay(delay, 450, time_offset)
	robot.move_relative(2, delay, 450)
	time.sleep(wait)

	wait = Robko01.calc_delay(delay, -200, time_offset)
	robot.move_relative(6, delay, -200)
	time.sleep(wait)

	wait = Robko01.calc_delay(delay, 400, time_offset)
	robot.move_relative(5, delay, 400)
	time.sleep(wait)

	wait = Robko01.calc_delay(delay, 300, time_offset)
	robot.move_relative(1, delay, 300)
	time.sleep(wait)

	wait = Robko01.calc_delay(delay, -150, time_offset)
	robot.move_relative(5, delay, -150)
	time.sleep(wait)

	wait = Robko01.calc_delay(delay, -300, time_offset)
	robot.move_relative(1, delay, -300)
	time.sleep(wait)

	wait = Robko01.calc_delay(delay, -900, time_offset)
	robot.move_relative(0, delay, -900)
	time.sleep(wait)

	wait = Robko01.calc_delay(delay, 300, time_offset)
	robot.move_relative(1, delay, 300)
	time.sleep(wait)

	wait = Robko01.calc_delay(delay, 150, time_offset)
	robot.move_relative(5, delay, 150)
	time.sleep(wait)

	wait = Robko01.calc_delay(delay, -300, time_offset)
	robot.move_relative(1, delay, -300)
	time.sleep(wait)

	wait = Robko01.calc_delay(delay, 200, time_offset)
	robot.move_relative(6, delay, 200)
	time.sleep(wait)

	wait = Robko01.calc_delay(delay, -450, time_offset)
	robot.move_relative(2, delay, -450)
	time.sleep(wait)

	wait = Robko01.calc_delay(delay, -450, time_offset)
	robot.move_relative(1, delay, -450)
	time.sleep(wait)

	wait = Robko01.calc_delay(delay, 450, time_offset)
	robot.move_relative(0, delay, 450)
	time.sleep(wait)

	wait = Robko01.calc_delay(delay, -400, time_offset)
	robot.move_relative(5, delay, -400)
	time.sleep(wait)
	
	# Disable joints.
	robot.disable()
	
# Data response handler.
def data_response(message):
	print "Message", message
	
# Main function.
def main():
	global port_name
	
	# Under Linux.
	if (os.name == "posix"):
		port_name = '\dev\ttyUSB0'
	# Under Windows.
	elif (os.name == "nt"):
		port_name = 'COM47'
	
	# Usage: (Time[ms], Steps, Offset[s])
	#delay = Robko01.calc_delay(5, 100, 1)
	
	# Usage: rights_kinematic(J1, J2, J3, J4, J5)
	#xyzpr = Robko01.rights_kinematic(0.0, 0.0, 0.0, 0.0, 0.0)
	#print 'X: ', xyzpr[0]
	#print 'Y: ', xyzpr[1]
	#print 'Z: ', xyzpr[2]
	#print 'P: ', xyzpr[3]
	#print 'R: ', xyzpr[4]
	#print ''
	
	# Usage: iverse_kinematic(X, Y, Z, P, R)
	#thitas = Robko01.iverse_kinematic(110.0, 0.0, 190.0, 0.0, 0.0)
	#print 'T0: ', thitas[0]
	#print 'T1: ', thitas[1]
	#print 'T2: ', thitas[2]
	#print 'T3: ', thitas[3]
	#print 'T4: ', thitas[4]
	#print ''
	
	# Create robot.
	robot = Robko01.Robko01(port_name)
	# Register data response handler.
	robot.data_response_handler(data_response)
	# Connect to the robot.
	robot.connect()
	# Run the demo program.
	demo_program(robot)
	# Disconnect from the robot.
	robot.disconnect()
	
# Run the program.
if(__name__ == '__main__'):
	# Try to run main().
	try:
		main()
		
	except TypeError:
		print('Type error ...')
		
	except KeyboardInterrupt:
		print('Shutting down the robot controller.')
