//timer1 header file

void InitTimer1();
