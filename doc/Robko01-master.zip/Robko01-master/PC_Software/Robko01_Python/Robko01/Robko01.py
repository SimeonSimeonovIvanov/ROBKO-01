#!/usr/bin/python
# -*- coding: utf-8 -*-

import serial
import os
import time
import math

# JOINT INDEXES
All = -1
Base = 0
Shoulder = 1
Elbow = 2
LD = 3
RD = 4
Gripper = 5
Pitch = 6
Roll = 7
	
# Страница 67 таблица 190
H  = 190;

# Не я знам от къде идва
# Константата трябва да се редактира!!!
C  = 20;

# Не я знам от къде идва
# Константата трябва да се редактира!!!
LG = 30;

# Не я знам от къде идва
# Константата трябва да се редактира!!!
R1 = 40;

# Страница 80 фигура 4.12
# Константата трябва да се редактира!!!
L1 = 40;

# Страница 80 фигура 4.12
# Константата трябва да се редактира!!!
L2 = 40;

# This class is dedicated to drive Robko01 TU-GAB driver. 
class Robko01():
	
	# COMMNUNICATION
	__serial_port = serial.Serial()
	
	__data_recieved_cb = None
	
	# PACKAGE LENGTH
	__PKG_LEN = 250
	
	# Debug
	__ENABLE_DEBUG = True
	
	# RESPONSE KEYS
	__EnableMotor = 'Enable motor'
	__DisableMotor = 'Disable motor'
	__Drive = 'Drive'
	__Direction = 'Direction'
	__MotorFlag = 'Motor Flag'
	__StepTime = 'StepTime'
	__StepsNumber = 'Steps Number'
	__CurrentStep = 'Current Step'
	__CurrentTimeout = 'Current Timeout'
	__CurrentEnable = 'Current Enable'
	__CurrentDisable = 'Current Disable'

	
	# DIRECTIONS
	CW = '+'
	CCW = '-'
	# JOINT INDEXES
	All = -1
	Base = 0
	Shoulder = 1
	Elbow = 2
	LD = 3
	RD = 4
	Gripper = 5
	Pitch = 6
	Roll = 7
	
	# Constructor
	def __init__(self, port_name):
		# Check the serial port name.
		if(port_name == None):
			raise ValueError('Must enter serial port name.')
			#self.__serial_port.port = 'COM81'
			#self.__serial_port.port = '/dev/ttyUSB0'
			#self.__serial_port.port = '/dev/ttyUSB7'
			#self.__serial_port.port = '/dev/ttyS2'		
		else:
			self.__serial_port.port = port_name

		# Baud rate to 9600.
		self.__serial_port.baudrate = 9600
		# Number of bits per bytes.
		self.__serial_port.bytesize = serial.EIGHTBITS
		# Set parity check: no parity.
		self.__serial_port.parity = serial.PARITY_NONE
		# Number of stop bits.
		self.__serial_port.stopbits = serial.STOPBITS_ONE 
		# B read.
		#self.__serial_port.timeout = None
		# Non-b read.
		#self.__serial_port.timeout = 1
		# Timeout b read
		self.__serial_port.timeout = 0.2
		# Disable software flow control
		self.__serial_port.xonxoff = False
		# Disable hardware (RTS/CTS) flow control
		self.__serial_port.rtscts = False
		# Disable hardware (DSR/DTR) flow control
		self.__serial_port.dsrdtr = False
		
	# Send request the serial port.
	def __send_request(self, command):
		if(self.__ENABLE_DEBUG == True):
			print 'Request:\r\n', command, '\r\n'
		if(self.__serial_port.isOpen()):
			# Send data to the robot.
			self.__serial_port.write(command + '\r\n')
			response = self.__serial_port.read(self.__PKG_LEN)
			self.__parse_response(response)
			
			if(self.__ENABLE_DEBUG == True):
				print 'Response:\r\n', response, '\r\n'
			
			self.__serial_port.flushInput()
			self.__serial_port.flushOutput()
		
	# Parse the incoming data.
	def __parse_response(self, response):
		response = response.strip()
		
		if(self.__data_recieved_cb != None):
			self.__data_recieved_cb(response)
			
		split_string = response.split('\r')
		for row in split_string:
			print row
			if(self.__Drive in row):
				trim_row = row.replace(self.__Drive, '')
				print 'Drive', trim_row
			elif(self.__StepsNumber in row):
				trim_row = row.replace(self.__StepsNumber, '')
				trim_row = trim_row.strip()
				print 'Steps Number', trim_row
		
		print 'LEN:', len(split_string)
		
	# Register event for data recieve.
	def data_response_handler(self, cb):
		self.__data_recieved_cb = cb

	# Connect to the device.
	def connect(self):
		self.__serial_port.open()
		# Flush the buffers.
		self.__serial_port.flushInput()
		self.__serial_port.flushOutput

	# Disconnect to the device.
	def disconnect(self):
		self.__serial_port.close()
	
	# Get revision of the board.
	def get_revision(self):
		command = '?RV'
		self.__send_request(command)
		
	# Enable motor.
	def enable(self, joint = -1):
		if(joint == Robko01.Pitch or joint == Robko01.Roll):
			self.enable(Robko01.LD)
			time.sleep(0.025)
			self.enable(Robko01.RD)
		elif (joint == -1):
			command = '?EA'
			self.__send_request(command)
		elif (joint <= 5 and joint >= 0):
			command = '{0}{1}'.format('?E', joint)
			self.__send_request(command)

	# Disable motor.
	def disable(self, joint = -1):
		if(joint == Robko01.Pitch or joint == Robko01.Roll):
			self.disable(Robko01.LD)
			time.sleep(0.025)
			self.disable(Robko01.RD)
		elif (joint == -1):
			command = '?NA'
			self.__send_request(command)
		elif (joint <= 5 and joint >= 0):
			command = '{0}{1}'.format('?N', joint)
			self.__send_request(command)

	# Enable Elbow motor.
	def enable_elbow(self, state):
		if (state):
			self.enable(Robko01.Elbow)
			time.sleep(0.05)
			self.enable(Robko01.Gripper)
		else:
			self.disable(Robko01.Elbow)
			time.sleep(0.05)
			self.disable(Robko01.Gripper)

	# Start single motor.
	def start_single(self, joint = -1):
		if (joint <= 5 and joint >= 0):
			command = '{0}{1}'.format('?S', joint)
			self.__send_request(command)
		elif (joint == -1):
			command = '?SA'
			self.__send_request(command)
			
	# Start multiple motors.
	def start_multi(self, states):
		if (len(states) >= 6):
			indexes = ''
			for index in range(0, len(states)):
				if(states[index] == True):
					state = '1'
				else:
					state = '0'
				indexes += state
				command = '{0}{1}'.format('?SD', indexes)
			self.__send_request(command)
			
	# Stop motor.
	def stop(self, joint = -1):
		if (joint <= 5 and joint >= 0):
			command = '{0}{1}'.format('?P', joint)
			self.__send_request(command)
		elif (joint == -1):
			command = '?PA'
			self.__send_request(command)
			
	# Read motor state.
	def read(self, joint = -1):
		if (joint <= 5 and joint >= 0):
			command = '{0}{1}'.format('?R', joint)
			self.__send_request(command)
		elif (joint == -1):
			command = '?RA'
			self.__send_request(command)
			
	# Set delay of the motor.
	def set_delay(self, joint, delay):
		if (joint <= 5 and joint >= 0):
			command = '{0}{1}:{2}'.format('?T', joint, str(delay).zfill(4))
			self.__send_request(command)
			
	# Set steps of the motor.
	def set_steps(self, joint, steps):
		if (joint <= 5 and joint >= 0):
			command = '{0}{1}:{2}'.format('?A', joint, str(steps).zfill(4))
			self.__send_request(command)
			
	# Direction of the motor.
	def set_direction(self, joint, direction):
		if (joint <= 5 and joint >= 0 and (direction == self.CW or direction == self.CCW)):
			command = '{0}{1}:{2}'.format('?D', joint, direction)
			self.__send_request(command)
			
	# Move the motor in relative mode.
	def move_relative(self, joint, delay, steps):
		if(joint == self.Elbow):
			direction = ''
			if(steps >= 0):
				direction = '+'
			else:
				direction = '-'
			steps = abs(steps)

			command = '{0}{1}:{2}{3}:{4}'.format('?F', 2, direction, str(steps).zfill(4), str(delay).zfill(4))
			self.__send_request(command)
			time.sleep(0.05)
			command = '{0}{1}:{2}{3}:{4}'.format('?F', 5, direction, str(steps).zfill(4), str(delay).zfill(4))
			self.move_relative(self.Gripper, delay, steps)
			
		if(joint == Robko01.Pitch):
			self.move_relative(Robko01.LD, delay, steps)
			time.sleep(0.05)
			self.move_relative(Robko01.RD, delay, steps)
			
		elif(joint == Robko01.Roll):
			self.move_relative(Robko01.LD, delay, steps)
			time.sleep(0.05)
			self.move_relative(Robko01.RD, delay, -steps)

		else:
			direction = ''
			if(steps >= 0):
				direction = '+'
			else:
				direction = '-'
			steps = abs(steps)

			command = '{0}{1}:{2}{3}:{4}'.format('?F', joint, direction, str(steps).zfill(4), str(delay).zfill(4))
			# delay sleep
			tmpdelay = int(abs(steps * delay * 2.5) / 1000)
			self.__send_request(command)	

	#def move_relative(self, command):
	#	self.move_relative(command.joint, command.delay, command.steps)
		
def calc_delay(steps, delay, time_offset):
	tmpdelay = int(abs(steps * delay * 2.5) / 1000) + time_offset
	return tmpdelay
	
def sign(value):
	sign = 1.0
	if(value > 0):
		sign = 1.0
	elif(value < 0):
		sign = -1.0
	else:
		sign = 0.0

		return sign

def iverse_kinematic(X0, Y0, Z0, P0, R0):
	
	RR = 0.0
	LF = 0.0
	RM = 0.0
	GA = 0.0
	AL = 0.0
	
	if (Z0 < 0):
		Z0 = 0
		
	if (Z0 < 300 and X0 < 0):
		X0 = 100

	RR = math.sqrt(X0 * X0 + Y0 * Y0)
	LF = 2 * L1 + LG
	
	if (Z0 == H):
		RM = LF
	elif (Z0 == 0):
		RM = math.sqrt((LF * LF) - (H * H))
	else:
		RM = math.sqrt((LF * LF) - ((H - Z0) * (H - Z0)))
		
	if (RR > RM):
		RR = RM
		
	P0 = P0 / C
	R0 = R0 / C
	R0 = RR - LG * math.cos(P0)
	Z0 = H - Z0 - LG * math.sin(P0)
	
	if (R0 == 0):
		GA = sign(Z0) * math.PI / 2
	else:
		GA = math.atan(Z0 / R0)
	
	AL = math.sqrt((R0 * R0) + (Z0 * Z0)) / 2
	AL = math.atan(math.sqrt((L1 * L1) - (AL * AL)) / AL)

	if (X0 == 0):
		T1 = sign(Y0) * math.PI / 2
	else:
		T1 = math.atan(Y0 / X0)
		
	T2 = GA - AL
	T3 = GA + AL
	T4 = P0 + R0 + R1 * T1
	T5 = P0 - R0 - R1 * T1
	
	return (T1, T2, T3, T4, T5)
	
def rights_kinematic(T1, T2, T3, T4, T5):

	RP = 0.0

	PP = (T4 + T5) / 2
	RR = (T4 - T5) / 2 - R1 * T1
	RP = L1 * math.cos(T2) + L2 * math.cos(T3) + LG * math.cos(PP)
	XX = RP * math.cos(T1)
	YY = RP * math.sin(T1)
	ZZ = H - L1 * math.sin(T2) - L2 * math.sin(T3) - LG * math.sin(PP)
	PP = PP * C
	RR = RR * C
	
	return (XX, YY, ZZ, PP, RR)
