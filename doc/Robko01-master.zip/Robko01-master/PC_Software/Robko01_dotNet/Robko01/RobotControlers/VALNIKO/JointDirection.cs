﻿
namespace Robko01.RobotControlers.VALNIKO
{
    public enum JointDirection : int
    {
        /// <summary>
        /// Clock ways.
        /// </summary>
        CW = 0,

        /// <summary>
        /// Contra clock ways.
        /// </summary>
        CCW = 1
    }
}
