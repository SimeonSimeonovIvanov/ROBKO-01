#include <pic18.h>
#include "timer1.h"




void InitTimer1()
{
T1CON = 0x31; //enable timer, prescaler 8:1
TMR1IE = 1; //ENABLE INTERRUPT
}
