﻿using System;
using System.Windows.Forms;

namespace KeystrokEventGenerator
{
    public class KeystrokMessageFilter : IMessageFilter
    {

        #region Events

        public event EventHandler<EventArgs> OnEscape;

        public event EventHandler<EventArgs> OnSave;

        public event EventHandler<EventArgs> OnOpen;

        public event EventHandler<EventArgs> OnCut;

        public event EventHandler<EventArgs> OnCopy;

        public event EventHandler<EventArgs> OnPaste;

        public event EventHandler<EventArgs> OnUndo;

        public event EventHandler<EventArgs> OnRedo;

        public event EventHandler<EventArgs> OnDelete;

        public event EventHandler<EventArgs> OnPan;

        #endregion

        #region Constructor

        /// <summary>
        /// Constructor
        /// </summary>
        public KeystrokMessageFilter()
        {
        
        }

        #endregion

        #region Implementation of IMessageFilter

        /// <summary>
        /// Filter of the key strokes.
        /// </summary>
        /// <param name="m">Message argument.</param>
        /// <returns></returns>
        public bool PreFilterMessage(ref Message m)
        {
            if ((m.Msg == 256 /*0x0100*/))
            {
                switch (((int)m.WParam) | ((int)Control.ModifierKeys))
                {
                    case KeyCombinations.ESCAPE:
                        if (this.OnEscape != null)
                        {
                            this.OnEscape(this, new EventArgs());
                        }
                        break;

                    case KeyCombinations.CTRL_S:
                        if (this.OnSave != null)
                        {
                            this.OnSave(this, new EventArgs());
                        }
                        break;

                    case KeyCombinations.CTRL_O:
                        if (this.OnOpen != null)
                        {
                            this.OnOpen(this, new EventArgs());
                        }
                        break;

                    case KeyCombinations.CTRL_C:
                        if (this.OnCopy != null)
                        {
                            this.OnCopy(this, new EventArgs());
                        }
                        break;

                    case KeyCombinations.CTRL_V:
                        if (this.OnPaste != null)
                        {
                            this.OnPaste(this, new EventArgs());
                        }
                        break;

                    case KeyCombinations.CTRL_X:
                        if (this.OnCut != null)
                        {
                            this.OnCut(this, new EventArgs());
                        }
                        break;

                    case KeyCombinations.CTRL_Z:
                        if (this.OnUndo != null)
                        {
                            this.OnUndo(this, new EventArgs());
                        }
                        break;

                    case KeyCombinations.CTRL_Y:
                        if (this.OnRedo != null)
                        {
                            this.OnRedo(this, new EventArgs());
                        }
                        break;

                    case KeyCombinations.DELETE:
                        if (this.OnDelete != null)
                        {
                            this.OnDelete(this, new EventArgs());
                        }
                        break;

                    case KeyCombinations.P:
                        if (this.OnPan != null)
                        {
                            this.OnPan(this, new EventArgs());
                        }
                        break;

                    //This does not work. It seems you can only check single character along with CTRL and ALT.
                    //case (int)(Keys.Control | Keys.Alt | Keys.K | Keys.P):
                    //    MessageBox.Show("You pressed ctrl + alt + k + p");
                    //    break;
                }
            }
            return false;
        }

        #endregion

    }
}
