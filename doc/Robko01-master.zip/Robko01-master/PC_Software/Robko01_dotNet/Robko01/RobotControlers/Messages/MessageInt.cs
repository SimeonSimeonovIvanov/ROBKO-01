﻿using System;

namespace Robko01.RobotControlers.Messages
{
    public class MessageInt : EventArgs
    {
        public int Value { get; private set; }

        public MessageInt(int value)
        {
            this.Value = value;
        }
    }
}
