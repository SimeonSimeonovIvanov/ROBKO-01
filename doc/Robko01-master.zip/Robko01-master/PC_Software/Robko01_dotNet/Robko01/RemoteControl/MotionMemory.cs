﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Robko01.RemoteControl
{
    [Serializable]
    public class MotionMemory
    {

        /// <summary>
        /// Address space.
        /// </summary>
        enum Addresses : ushort
        {
            BaseSteps = 0,
            ShoulderSteps = 1,
            ElbowSteps = 2,
            PichSteps = 3,
            RollSteps = 4,
            GripperSteps = 5,

            BASEDelay = 6,
            SHOULDERDelay = 7,
            ELBOWDelay = 8,
            PichDelay = 9,
            RollDelay = 10,
            GripperDelay = 11,

            BaseState = 12,
            ShoulderState = 13,
            ElbowState = 14,
            PichState = 15,
            RollState = 16,
            GripperState = 17,
            
            Mode = 18
        }

        /// <summary>
        /// Base address of the structure.
        /// </summary>
        private ushort baseAddress;

        #region Priperties

        public int SizeOfStruct
        {
            get
            {
                return (int)Enum.GetValues(typeof(Addresses)).Cast<Addresses>().Last() + 1;
            }
        }

        public int BaseSteps
        {
            get
            {
                return this.baseAddress + (ushort)Addresses.BaseSteps; 
            }
        }

        public int ShoulderSteps
        {
            get
            {
                return this.baseAddress + (ushort)Addresses.ShoulderSteps;
            }
        }

        public int ElbowSteps
        {
            get
            {
                return this.baseAddress + (ushort)Addresses.ElbowSteps;
            }
        }

        public int PichSteps
        {
            get
            {
                return this.baseAddress + (ushort)Addresses.PichSteps;
            }
        }

        public int RollSteps
        {
            get
            {
                return this.baseAddress + (ushort)Addresses.RollSteps;
            }
        }

        public int GripperSteps
        {
            get
            {
                return this.baseAddress + (ushort)Addresses.GripperSteps;
            }
        }

        public int BaseDelay
        {
            get
            {
                return this.baseAddress + (ushort)Addresses.BASEDelay;
            }
        }

        public int ShoulderDelay
        {
            get
            {
                return this.baseAddress + (ushort)Addresses.SHOULDERDelay;
            }
        }

        public int ElbowDelay
        {
            get
            {
                return this.baseAddress + (ushort)Addresses.ELBOWDelay;
            }
        }

        public int PichDelay
        {
            get
            {
                return this.baseAddress + (ushort)Addresses.PichDelay;
            }
        }

        public int RollDelay
        {
            get
            {
                return this.baseAddress + (ushort)Addresses.RollDelay;
            }
        }
        
        public int GripperDelay
        {
            get
            {
                return this.baseAddress + (ushort)Addresses.GripperDelay;
            }
        }

        public int BaseState
        {
            get
            {
                return this.baseAddress + (ushort)Addresses.BaseState;
            }
        }

        public int ShoulderState
        {
            get
            {
                return this.baseAddress + (ushort)Addresses.ShoulderState;
            }
        }

        public int ElbowState
        {
            get
            {
                return this.baseAddress + (ushort)Addresses.ElbowState;
            }
        }

        public int PichState
        {
            get
            {
                return this.baseAddress + (ushort)Addresses.PichState;
            }
        }

        public int RollState
        {
            get
            {
                return this.baseAddress + (ushort)Addresses.RollState;
            }
        }

        public int GripperState
        {
            get
            {
                return this.baseAddress + (ushort)Addresses.GripperState;
            }
        }

        public int Mode
        {
            get
            {
                return this.baseAddress + (ushort)Addresses.Mode;
            }
        }

        #endregion

        #region Constructor

        public MotionMemory(ushort baseAddress)
        {
            this.baseAddress = baseAddress;
        }

        #endregion
    }
}
