//eeprom header file

void Write_word(int data_word,char adr);
int Read_word(char adr);
void Write_double(long data_word,char adr);
long Read_double(char adr);
