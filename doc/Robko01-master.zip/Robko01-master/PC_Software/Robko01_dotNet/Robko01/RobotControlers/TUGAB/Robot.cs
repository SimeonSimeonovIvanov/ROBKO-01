﻿using Robko01.RobotControlers.Commands;
using Robko01.RobotControlers.Messages;
using System;
using System.IO.Ports;
using System.Threading;

namespace Robko01.RobotControlers.TUGAB
{

    /// <summary>
    /// Robko01 controller.
    /// </summary>
    public class Robko01 : Communicator, IDisposable
    {

        #region Constants

        private const string TERMIN = "\n";
        
        #endregion

        #region Variables

        /// <summary>
        /// Delimiting characters.
        /// </summary>
        private char[] delimiterChars = { '\n' };

        private int[] steps = new int[6];

        #endregion

        #region Properties

        /// <summary>
        /// True when robogt is folowing the commands.
        /// Else false.
        /// </summary>
        public bool IsRuning
        {
            private set;
            get;
        }

        #endregion

        #region Events

        /// <summary>
        /// Raise when motor is runing.
        /// </summary>
        public event EventHandler<EventArgs> OnMoveing;

        /// <summary>
        /// Raise when motor stops moveing.
        /// </summary>
        public event EventHandler<EventArgs> OnNotMoveing;


        #endregion

        #region Constructor / Destructor

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="port">Comunication port.</param>
        public Robko01(string portName) : base(portName)
        {
        }

        /// <summary>
        /// Destructor
        /// </summary>
        ~Robko01()
        {
            this.Dispose(false);
        }

        /// <summary>
        /// Dispose
        /// </summary>
        public void Dispose()
        {
            this.Dispose(false);
        }

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                // Add resources for disposing.
            }

            this.Disconnect();
        }

        #endregion

        #region Public Methods

        #region Manual

        /// <summary>
        /// Enables the motor.
        /// </summary>
        /// <param name="joint">Index of the motor.</param>
        public void Enable(int joint = -1)
        {
            if (joint <= 5 && joint >= 0)
            {
                string command = String.Format("?E{0}", joint) + TERMIN;
                this.SendRequest(command);
            }
            else if (joint == -1)
            {
                string command = "?EA";
                this.SendRequest(command);
            }
        }

        /// <summary>
        /// Disable the motor.
        /// </summary>
        /// <param name="joint">Index of the motor.</param>
        public void Disable(int joint = -1)
        {
            if (joint <= 5 && joint >= 0)
            {
                string command = String.Format("?N{0}", joint) + TERMIN;
                this.SendRequest(command);
            }
            else if (joint == -1)
            {
                string command = "?NA";
                this.SendRequest(command);
            }
        }

        /// <summary>
        /// Start the motor.
        /// </summary>
        /// <param name="joint">Index of the motor.</param>
        public void Start(int joint = -1)
        {
            if (joint <= 5 && joint >= 0)
            {
                string command = String.Format("?S{0}", joint) + TERMIN;
                this.SendRequest(command);
            }
            else if (joint == -1)
            {
                string command = "?SA";
                this.SendRequest(command);
            }
        }

        /// <summary>
        /// Start the motor marked with index 1 or true.
        /// Else not starting.
        /// </summary>
        /// <param name="states">Array of start states.</param>
        public void Start(bool[] states)
        {
            if (states.Length >= 6)
            {
                string indexes = "";
                for (int index = 0; index < states.Length; index++)
                {
                    string state = states[index] ? "1" : "0";
                    indexes += state;
                }

                string command = "?SD" + indexes;
                this.SendRequest(command);
            }
        }

        /// <summary>
        /// Stop the motor.
        /// </summary>
        /// <param name="joint">Index of the motor.</param>
        public void Stop(int joint = -1)
        {
            if (joint <= 5 && joint >= 0)
            {
                string command = String.Format("?P{0}", joint) + TERMIN;
                this.SendRequest(command);
            }
            else if (joint == -1)
            {
                string command = "?PA";
                this.SendRequest(command);
            }
        }

        /// <summary>
        /// Read the motor state.
        /// </summary>
        /// <param name="joint">Index of the motor.</param>
        public void Read(int joint = -1)
        {
            if (joint <= 5 && joint >= 0)
            {
                string command = String.Format("?R{0}", joint) + TERMIN;
                this.SendRequest(command);
            }
            else if (joint == -1)
            {
                string command = "?RA";
                this.SendRequest(command);
            }
        }

        /// <summary>
        /// Set the delay between two steps.
        /// </summary>
        /// <param name="joint">Index of the motor.</param>
        /// <param name="delay">Delay of steps.</param>
        public void Delay(int joint, int delay)
        {
            if (joint <= 5 && joint >= 0)
            {
                string command = String.Format("?T{0}:{1:D4}", joint, delay) + TERMIN;
                this.SendRequest(command);
            }
        }

        /// <summary>
        /// Set the delay between two steps.
        /// </summary>
        /// <param name="joint">Index of the motor.</param>
        /// <param name="steps">Steps count.</param>
        public void Step(int joint, int steps)
        {
            if (joint <= 5 && joint >= 0)
            {
                string command = String.Format("?A{0}:{1:D4}", joint, steps) + TERMIN;
                this.SendRequest(command);
            }
        }

        /// <summary>
        /// Set clock wise direction of the motor.
        /// </summary>
        /// <param name="joint">Index of the motor.</param>
        public void SetCW(int joint)
        {
            if (joint <= 5 && joint >= 0)
            {
                string command = String.Format("?D{0}:{1}", joint, JointDirection.CW) + TERMIN;
                this.SendRequest(command);
            }
        }

        /// <summary>
        /// Set contra clock wise direction of the motor.
        /// </summary>
        /// <param name="joint">Index of the motor.</param>
        public void SetCCW(int joint)
        {

            {
                if (joint <= 5 && joint >= 0)
                {
                    string command = String.Format("?D{0}:{1}", joint, JointDirection.CCW) + TERMIN;
                    this.SendRequest(command);
                }
            }
        }

        /// <summary>
        /// Move relative single motor.
        /// </summary>
        /// <param name="joint">Index of the motor.</param>
        /// <param name="direction">Direction of the movement.</param>
        /// <param name="delay">Delay between steps.</param>
        /// <param name="steps">Steps count.</param>
        public void MoveRelative(int joint, int delay, int steps)
        {
            if (this.IsConnected)
            {
                string direction = "";

                if(steps >= 0)
                {
                    direction = JointDirection.CW;
                }
                else
                {
                    direction = JointDirection.CCW;
                }

                steps = Math.Abs(steps);
                string command = String.Format("?F{0}:{1}{2:D4}:{3:D4}", joint, direction, steps, delay) + TERMIN;
                
                this.SendRequest(command);

                this.IsRuning = true;
                if(this.OnMoveing != null)
                {
                    this.OnMoveing(this, new EventArgs());
                }

                Thread wait = new Thread(new ThreadStart(() => {
                    float tmpDelay = Math.Abs(steps * delay * 2.5f);
                    Thread.Sleep((int)tmpDelay);

                    this.IsRuning = false;
                    if (this.OnNotMoveing != null)
                    {
                        this.OnNotMoveing(this, new EventArgs());
                    }
                }));
                wait.Start();
            }   
        }

        /// <summary>
        /// Move relative single motor.
        /// </summary>
        /// <param name="joint">Axis name.</param>
        /// <param name="direction">Direction of the movement.</param>
        /// <param name="delay">Delay between steps.</param>
        /// <param name="steps">Steps count.</param>
        public void MoveRelative(JointName joint, int delay, int steps)
        {
            this.MoveRelative((int)joint, delay, steps);
        }

        /// <summary>
        /// Move relative single motor.
        /// </summary>
        /// <param name="command">Command</param>
        public void MoveRelative(MotionCommand command)
        {
            switch((JointName)command.Axis)
            {
                case JointName.Elbow:
                    this.MoveRelativeElbow(command.Delay, command.Steps);
                    break;

                case JointName.Pitch:
                    this.MoveRelativePich(command.Delay, command.Steps);
                    break;

                case JointName.Roll:
                    this.MoveRelativeRoll(command.Delay, command.Steps);
                    break;

                default:
                    this.MoveRelative(command.Axis, command.Delay, command.Steps);
                    break;
            }

            //TODO: Lavash ...
        }

        /// <summary>
        /// Enables or disables the elbow joint.
        /// </summary>
        /// <param name="state">Enable / Disable</param>
        public void EnableElbow(bool state)
        {
            if (state)
            {
                this.Enable((int)JointName.Elbow);
                Thread.Sleep(50);
                this.Enable((int)JointName.Gripper);
            }
            else
            {
                this.Disable((int)JointName.Elbow);
                Thread.Sleep(50);
                this.Disable((int)JointName.Gripper);
            }
        }

        /// <summary>
        /// Move relative the Elbow joiunt.
        /// </summary>
        /// <param name="delay">Steps</param>
        /// <param name="steps">Delay</param>
        public void MoveRelativeElbow(int delay, int steps)
        {
            this.MoveRelative(JointName.Elbow, delay, steps);
            Thread.Sleep(50);
            this.MoveRelative(JointName.Gripper, delay, steps);
        }

        /// <summary>
        /// Enables or disables the pitch / roll movement.
        /// </summary>
        /// <param name="state">Enable / Disable</param>
        public void EnablePichRoll(bool state)
        {
            if (state)
            {
                this.Enable((int)JointName.LD);
                Thread.Sleep(25);
                this.Enable((int)JointName.RD);
            }
            else
            {
                this.Disable((int)JointName.LD);
                Thread.Sleep(25);
                this.Disable((int)JointName.RD);
            }
        }

        /// <summary>
        /// Move relative the Pitch axis.
        /// </summary>
        /// <param name="delay">Steps</param>
        /// <param name="steps">Delay</param>
        public void MoveRelativePich(int delay, int steps)
        {
            this.MoveRelative(JointName.LD, delay, steps);
            Thread.Sleep(50);
            this.MoveRelative(JointName.RD, delay, steps);
        }

        /// <summary>
        /// Move relative the Roll axis.
        /// </summary>
        /// <param name="delay">Steps</param>
        /// <param name="steps">Delay</param>
        public void MoveRelativeRoll(int delay, int steps)
        {
            this.MoveRelative(JointName.LD, delay, steps);
            Thread.Sleep(50);
            this.MoveRelative(JointName.RD, delay, -steps);
        }

        #endregion

        #endregion

    }
}
